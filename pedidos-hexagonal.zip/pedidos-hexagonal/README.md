# Arquitectura Hexagonal en JavaScript: ejemplo de pedidos

Proyecto didáctico, sin dependencias externas (solo Node.js 18+).

## Estructura

```
src/
├── domain/                      # Reglas de negocio (no importa nada)
│   └── Pedido.js
├── application/
│   ├── ports/
│   │   ├── in/CrearPedidoUseCase.js      # Puerto de entrada
│   │   └── out/                          # Puertos de salida
│   │       ├── PedidoRepository.js
│   │       └── Notificador.js
│   └── services/CrearPedidoService.js    # Implementa el caso de uso
├── infrastructure/adapters/
│   ├── in/   cli.js, http.js             # Adaptadores de entrada
│   └── out/  InMemoryPedidoRepository.js # Adaptadores de salida
│             FilePedidoRepository.js
│             ConsoleNotificador.js
└── main.js                               # Raíz de composición (conecta todo)
test/CrearPedidoService.test.js
```

## Cómo explicar el código (orden sugerido)

1. `domain/Pedido.js`: reglas de negocio, sin dependencias.
2. `ports/`: los contratos (qué necesito, no cómo se hace).
3. `services/CrearPedidoService.js`: orquesta usando solo puertos.
4. `adapters/`: implementaciones concretas (CLI, HTTP, memoria, archivo).
5. `main.js`: el único lugar donde se eligen y conectan los adaptadores.

## Demo en vivo

```bash
# 1) CLI + memoria
npm run cli -- Ana "Camisa:50000:2" "Gorra:20000:1"

# 2) CLI + archivo (se crea pedidos.json): CAMBIA SOLO UN ADAPTADOR
REPO=archivo npm run cli -- Ana "Camisa:50000:2" "Gorra:20000:1"

# 3) Misma lógica, otra puerta de entrada: API REST
REPO=archivo npm run http
curl -X POST http://localhost:3000/pedidos \
  -H "Content-Type: application/json" \
  -d '{"cliente":"Luis","items":[{"nombre":"Zapatos","precio":120000,"cantidad":1}]}'

# 4) Probar una regla de negocio (pedido vacío -> error 400)
curl -X POST http://localhost:3000/pedidos \
  -H "Content-Type: application/json" \
  -d '{"cliente":"Luis","items":[]}'

# 5) Tests sin BD ni servidor
npm test
```

## Mensaje clave para la exposición

El dominio y el servicio **no cambian** cuando cambias de memoria a archivo, o
de CLI a HTTP. Solo cambian los adaptadores. Eso es la arquitectura hexagonal:
**la dependencia siempre apunta hacia el centro**.

## Ventajas y desventajas

- Ventajas: testeable, adaptadores intercambiables, el negocio queda aislado.
- Desventajas: más archivos y clases al inicio; puede ser excesivo en proyectos muy pequeños.
