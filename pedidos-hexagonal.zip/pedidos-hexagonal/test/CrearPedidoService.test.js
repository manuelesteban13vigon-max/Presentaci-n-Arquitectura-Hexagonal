// ============================================================
// TEST DEL SERVICIO (sin base de datos, sin HTTP, sin consola)
// ------------------------------------------------------------
// Esta es una de las grandes ventajas: como el servicio depende de
// puertos, en los tests le pasamos adaptadores falsos y probamos
// la lógica pura.
// ============================================================

import { test } from "node:test";
import assert from "node:assert/strict";
import { CrearPedidoService } from "../src/application/services/CrearPedidoService.js";
import { InMemoryPedidoRepository } from "../src/infrastructure/adapters/out/InMemoryPedidoRepository.js";

// Notificador falso: solo recuerda a quién avisó
class NotificadorFalso {
  constructor() {
    this.avisados = [];
  }
  async pedidoCreado(pedido) {
    this.avisados.push(pedido.id);
  }
}

function crearServicio() {
  const pedidoRepository = new InMemoryPedidoRepository();
  const notificador = new NotificadorFalso();
  const servicio = new CrearPedidoService({ pedidoRepository, notificador });
  return { servicio, pedidoRepository, notificador };
}

test("crea un pedido, calcula el total, lo guarda y notifica", async () => {
  const { servicio, pedidoRepository, notificador } = crearServicio();

  const resultado = await servicio.ejecutar({
    cliente: "Ana",
    items: [
      { nombre: "Camisa", precio: 50000, cantidad: 2 },
      { nombre: "Gorra", precio: 20000, cantidad: 1 },
    ],
  });

  assert.equal(resultado.total, 120000);
  assert.equal((await pedidoRepository.listar()).length, 1);
  assert.deepEqual(notificador.avisados, [1]);
});

test("rechaza un pedido sin productos", async () => {
  const { servicio, pedidoRepository, notificador } = crearServicio();

  await assert.rejects(
    () => servicio.ejecutar({ cliente: "Ana", items: [] }),
    /al menos un producto/
  );
  // Si falla la regla de negocio, no se guarda ni se notifica
  assert.equal((await pedidoRepository.listar()).length, 0);
  assert.equal(notificador.avisados.length, 0);
});

test("rechaza un pedido sin cliente", async () => {
  const { servicio } = crearServicio();

  await assert.rejects(
    () =>
      servicio.ejecutar({
        cliente: "",
        items: [{ nombre: "Camisa", precio: 1000, cantidad: 1 }],
      }),
    /cliente/
  );
});
