// ============================================================
// ADAPTADOR DE ENTRADA #2: API REST (HTTP)
// ------------------------------------------------------------
// Traduce una petición HTTP (POST /pedidos con JSON) a una llamada
// al MISMO caso de uso que usa el CLI. Solo cambia la "puerta".
// ============================================================

import { createServer } from "node:http";

export function iniciarHttp(crearPedidoUseCase, puerto = 3000) {
  const servidor = createServer(async (req, res) => {
    if (req.method === "POST" && req.url === "/pedidos") {
      let cuerpo = "";
      for await (const trozo of req) cuerpo += trozo;

      try {
        const comando = JSON.parse(cuerpo);
        const resultado = await crearPedidoUseCase.ejecutar(comando);
        res.writeHead(201, { "Content-Type": "application/json" });
        res.end(JSON.stringify(resultado));
      } catch (err) {
        // Errores de reglas de negocio -> 400 Bad Request
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: err.message }));
      }
      return;
    }

    res.writeHead(404, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Ruta no encontrada" }));
  });

  servidor.listen(puerto, () => {
    console.log(`🌐 API escuchando en http://localhost:${puerto}`);
  });
  return servidor;
}
