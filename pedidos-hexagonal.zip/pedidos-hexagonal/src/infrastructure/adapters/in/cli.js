// ============================================================
// ADAPTADOR DE ENTRADA #1: línea de comandos (CLI)
// ------------------------------------------------------------
// Traduce lo que escribe el usuario en la terminal a una llamada
// al puerto de entrada (el caso de uso). No tiene lógica de negocio.
// ============================================================

export function iniciarCli(crearPedidoUseCase) {
  const [cliente, ...productos] = process.argv.slice(2);

  if (!cliente || productos.length === 0) {
    console.log('Uso: node src/main.js Cliente "Producto:precio:cantidad" ...');
    console.log('Ej:  ENTRADA=cli node src/main.js Ana "Camisa:50000:2" "Gorra:20000:1"');
    return;
  }

  // Formato "nombre:precio:cantidad" -> objeto item
  const items = productos.map((texto) => {
    const [nombre, precio, cantidad] = texto.split(":");
    return { nombre, precio: Number(precio), cantidad: Number(cantidad) };
  });

  crearPedidoUseCase
    .ejecutar({ cliente, items })
    .then((resultado) => console.log("✅ Resultado:", resultado))
    .catch((err) => console.error("❌ Error:", err.message));
}
