// ============================================================
// DOMINIO  (el centro del hexágono)
// ------------------------------------------------------------
// Aquí viven las reglas de negocio. Este archivo NO importa nada:
// no sabe qué es una base de datos, ni HTTP, ni la consola.
// ============================================================

export class Pedido {
  constructor({ id, cliente, items }) {
    // Regla de negocio 1: un pedido necesita cliente
    if (!cliente || cliente.trim() === "") {
      throw new Error("El pedido debe tener un cliente");
    }
    // Regla de negocio 2: un pedido no puede estar vacío
    if (!Array.isArray(items) || items.length === 0) {
      throw new Error("El pedido debe tener al menos un producto");
    }
    // Regla de negocio 3: cantidades y precios válidos
    for (const item of items) {
      if (item.cantidad <= 0 || item.precio < 0) {
        throw new Error(`Producto inválido: ${item.nombre}`);
      }
    }

    this.id = id;
    this.cliente = cliente;
    this.items = items;
    this.fecha = new Date().toISOString();
  }

  // Regla de negocio 4: el total se calcula aquí, no en el controlador
  // ni en la base de datos.
  calcularTotal() {
    return this.items.reduce((suma, i) => suma + i.precio * i.cantidad, 0);
  }
}
