// ============================================================
// PUERTO DE ENTRADA: CrearPedidoUseCase
// ------------------------------------------------------------
// Define QUÉ puede hacer el mundo exterior con nuestra aplicación.
// El CLI y la API REST dependen de este contrato, no del servicio
// concreto.
// ============================================================

export class CrearPedidoUseCase {
  /**
   * @param {{ cliente: string, items: Array<{nombre: string, precio: number, cantidad: number}> }} comando
   * @returns {Promise<{ id: number, cliente: string, total: number }>}
   */
  async ejecutar(_comando) {
    throw new Error("Método 'ejecutar' no implementado");
  }
}
