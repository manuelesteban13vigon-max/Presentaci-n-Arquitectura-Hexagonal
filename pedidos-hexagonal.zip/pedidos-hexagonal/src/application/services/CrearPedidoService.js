// ============================================================
// SERVICIO DE APLICACIÓN: CrearPedidoService
// ------------------------------------------------------------
// Implementa el puerto de ENTRADA y usa los puertos de SALIDA.
// Orquesta el caso de uso, pero las reglas de negocio las tiene
// el dominio (Pedido).
//
// Fíjate: recibe las dependencias por el constructor
// (inyección de dependencias). Nunca hace `new` de un adaptador.
// ============================================================

import { Pedido } from "../../domain/Pedido.js";
import { CrearPedidoUseCase } from "../ports/in/CrearPedidoUseCase.js";

export class CrearPedidoService extends CrearPedidoUseCase {
  constructor({ pedidoRepository, notificador }) {
    super();
    this.pedidoRepository = pedidoRepository; // puerto de salida
    this.notificador = notificador; // puerto de salida
  }

  async ejecutar({ cliente, items }) {
    // 1. Generar el id (en un sistema real lo daría la BD)
    const existentes = await this.pedidoRepository.listar();
    const id = existentes.length + 1;

    // 2. Crear la entidad: aquí se validan las reglas de negocio
    const pedido = new Pedido({ id, cliente, items });

    // 3. Guardar (sin saber dónde ni cómo)
    await this.pedidoRepository.guardar(pedido);

    // 4. Notificar (sin saber por qué canal)
    await this.notificador.pedidoCreado(pedido);

    // 5. Devolver un resultado simple, no la entidad completa
    return { id: pedido.id, cliente: pedido.cliente, total: pedido.calcularTotal() };
  }
}
