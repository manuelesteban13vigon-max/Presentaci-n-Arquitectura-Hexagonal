// ============================================================
// main.js — RAÍZ DE COMPOSICIÓN
// ------------------------------------------------------------
// Este es el ÚNICO lugar donde se "conecta" todo: se eligen los
// adaptadores concretos y se inyectan en el servicio.
//
// Cambiar de adaptador = cambiar una variable de entorno:
//   REPO=memoria (por defecto)  |  REPO=archivo
//   ENTRADA=cli  (por defecto)  |  ENTRADA=http
// ============================================================

import { CrearPedidoService } from "./application/services/CrearPedidoService.js";
import { InMemoryPedidoRepository } from "./infrastructure/adapters/out/InMemoryPedidoRepository.js";
import { FilePedidoRepository } from "./infrastructure/adapters/out/FilePedidoRepository.js";
import { ConsoleNotificador } from "./infrastructure/adapters/out/ConsoleNotificador.js";
import { iniciarCli } from "./infrastructure/adapters/in/cli.js";
import { iniciarHttp } from "./infrastructure/adapters/in/http.js";

// 1. Elegir adaptadores de SALIDA
const pedidoRepository =
  process.env.REPO === "archivo"
    ? new FilePedidoRepository("./pedidos.json")
    : new InMemoryPedidoRepository();
const notificador = new ConsoleNotificador();

// 2. Crear el servicio inyectándole los adaptadores
const crearPedido = new CrearPedidoService({ pedidoRepository, notificador });

// 3. Elegir adaptador de ENTRADA
if (process.env.ENTRADA === "http") {
  iniciarHttp(crearPedido);
} else {
  iniciarCli(crearPedido);
}
